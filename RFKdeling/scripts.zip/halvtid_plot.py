# Write your code here :-)
# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.

Her viser jeg et eksempel hvordan elever kan bruke python i naturfag.
Oppgaver er å simulere halveringstid med terningkast (plukk ut 6-ere).
Etter terningkast blir resultatene presentert på skjerm og i en graf.
Nye saker er nestet "for" (gjenta) loops, random funksjon 
(for terningkast) og list (array, for å samla data i en liste. 
Her skriver jeg ikke kode på nytt, men kopierer kode 
in i script og etterpå kjører jeg script. En kan laste ned script 
(og alle brukte eksempler): scripts.zip
"""
#import moduler
import matplotlib.pyplot as plt
import random

#antall = 10000
antall = int(input("Hvor mange terninger? "))
#gjenta = 50
gjenta = int(input("Hvor mange kast? "))
listAntall = []
listKast = []

#definer funksjon
def main(antall):
  # definer start antall for 6er
    for i in range (0, gjenta):
        seks = 0

    # kast og summer #6r!
        for i in range(0, antall):
            tall = random.randint(1,6)
            if tall == 6:
                seks += 1

    #print("antall 6: ", seks)    # for testing, utkommentert nå

    # terninger minus 6-er og lage en list
        antall = antall - seks
        listAntall.append(antall)

main(antall)
kast = 0
for i in range(0, gjenta):
    kast += 1
    listKast.append(kast)
print("antall ganger kastet: ", listKast)
print("antall terninger etter 6-er er fjernet: ", listAntall)

# Tegner grafen
plt.scatter (listKast,listAntall)
plt.plot (listKast,listAntall)

# Navn på x-aksen
plt.xlabel("antall ganger kastet: ")

# Navn på y-aksen
plt.ylabel("antall terninger etter 6-er er fjernet: ")

# vis rutenett
plt.grid()

# Vi kan gi grafen vår et navn.
plt.title("Simulasjon halveringstid")

plt.show()