# Write your code here :-)
# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#importer moduler
from numpy import linspace
import matplotlib.pyplot as plt

#definer variabler
x = linspace(0, 10, 100)
y = x**2

#tegn grafen
plt.plot (x, y)     # tegner opp grafen
plt.xlabel("x")     # skriver x langs x-aksen
plt.ylabel("y")     # skriver y
plt.grid()          # tegner rutenett
plt.show()          # gjør grafen synlig