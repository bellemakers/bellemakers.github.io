# Write your code here :-)
# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.

I denne oppgave skal script spør først om noen data
(a, b og c i ligning ax^2 + bx + c).
Etter bruker har ført inn data skal script kjøre med 0, 1 eller 2 løsninger.
"""

#import module (square root fra math)
from math import sqrt

#Fortell om oppgave, instruer bruker
print("Finn løsninger for andregrads ligninger!")
print(" ")    # tomt linje
print("ax^2 + bx + c")
print(" ")

#Spør om variabler a, b og c
a = float(input("a = "))
b = float(input("b = "))
c = float(input("c = "))

#Definer funksjon
def f(a,b,c):
    return b**2 - 4 * a * c

if f(a,b,c) > 0:
    x_1 = (-b + sqrt(f(a,b,c)))/(2*a)
    x_2 = (-b - sqrt(f(a,b,c)))/(2*a)
    print("2 løsninger!", x_1, "og", x_2, ".")
elif f(a,b,c) < 0:
    print("Ingen løsning!")
else:
    x = -b/(2*a)
    print("1 løsning!", x, ".")