<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>mottar variabele i database fra PHP</title>
        <style media="screen">
body {
    background-color: #e0e0e0;
	font-family: "Century Gothic", Arial, sans-serif;
	font-size: 24px;
	color: #323232;
}

h1 {
    color: #2E0927; /* Define chapter looks (color) GVD */
}

h3 {
    color: #D90000;
}
    </style>
  </head>
  <body>

  
<?php
echo "<H3>Mottar en variabel</H3>";
// å få tak i variabler
if(isset($_GET["blad_id"])) {
    $blad_id = $_GET["blad_id"];
	$bladnavn = $_GET["bladnavn"];
} else {
   die("Du må angi et blad.");
}
echo "<H3>$blad_id, $bladnavn</H3><p>";

// Tilkoblingsinformasjon
$tjener = "localhost";
$brukernavn = "root";
$passord = "root";
//OBS: min database heter tegneseriefigurer_mb, skriv inn navn til din database!!
$database = "tegneseriefigurer_mb";

// Opprette en kobling
$kobling = new mysqli($tjener, $brukernavn, $passord, $database);

//Oppgave 16.12: aktiver regel 47 (fjern //) og deaktiver regel 48 (sett inn //)
//$sql = "SELECT * FROM figur";
$sql = "SELECT * FROM figur WHERE blad_id=$blad_id";
//Oppgave 16.13: aktiver regel 50 (fjern //) og deaktiver regel 48 (sett inn //)
//$sql = "SELECT * FROM figur JOIN blad ON figur.blad_id=blad.blad_id";
$resultat = $kobling->query($sql);

while($rad = $resultat->fetch_assoc()) {
	$figurnavn = $rad["figurnavn"];
	$aarstall = $rad["aarstall"];
	$bladnavn = $rad["bladnavn"];

	echo "Figuren $figurnavn så dagens lys i $aarstall. <br>";
//	Oppgave 16.13: aktiver regel 60 (fjern //) og deaktiver regel 58 (sett inn //)	
//	echo "Figuren $figurnavn så dagens lys i $aarstall i $bladnavn. <br>";
}
?>
	<p>&nbsp;</p>
	<p align="center"> <a href="kobling_sel2.php"> Tilbake til kobling_sel2.php</a></p>
 </body>
</html>