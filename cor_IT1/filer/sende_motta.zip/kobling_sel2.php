<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>SELECT i database fra PHP, del 2</title>
        <style media="screen">
body {
    background-color: #e0e0e0;
	font-family: "Century Gothic", Arial, sans-serif;
	font-size: 24px;
	color: #323232;
}

h1 {
    color: #2E0927;
}

h3 {
    color: #D90000;
}
    </style>
  </head>
  <body>

  <H1>SELECT i database fra PHP, del 2 (S188-192)</H1>
  
<?php
echo "<H3>Start opp MAMP og sjekk tilkoblingen!</H3>";

// Tilkoblingsinformasjon
$tjener = "localhost";
$brukernavn = "root";
$passord = "root";
//OBS: min database heter tegneseriefigurer_mb, skriv inn navn til din database!!
$database = "tegneseriefigurer_mb";

// Opprette en kobling
$kobling = new mysqli($tjener, $brukernavn, $passord, $database);

// Sending av variabler
echo "<H3>Sende en variabel (tabell: igjen utspørring!)</H3>";
echo "<table>";
echo "<tr>";
	echo "<th>blad_id</th>";
	echo "<th>bladnavn</th>";
echo "</tr>";

// Definer utspørring og spør ut
$sql = "SELECT * FROM blad";
$resultat = $kobling->query($sql);

while($rad = $resultat->fetch_assoc()) {
	$blad_id = $rad["blad_id"];
	$bladnavn = $rad["bladnavn"];
	
echo "<tr>";
	echo "<td>$blad_id</td>";
	// sende 1 variabel:
	// echo "<td><a href='figurer.php?blad_id=$blad_id'>$bladnavn</a></td>";
	// sende 2 variabler:
	echo "<td><a href='figurer.php?blad_id=$blad_id&bladnavn=$bladnavn'>$bladnavn</a></td>";
echo "</tr>";
}

echo "</table>";


echo "<H3>Mottar 1 (2) variabler (tabell: igjen utspørring!)</H3>";
echo "Når du klikker på lenker fra 'sending av variabler' 
	og du har programmert figurer.php som står på side 191 
	og 192, blir resultat som i Figur 16.9";
echo "<H3>Hvis du fikk det til: Gratulerer!!</H3>";	


?>

</body>
</html>