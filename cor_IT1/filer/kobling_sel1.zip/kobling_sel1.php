<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>SELECT i database fra PHP, del 1</title>
        <style media="screen">
body {
    background-color: #e0e0e0;
	font-family: "Century Gothic", Arial, sans-serif;
	font-size: 24px;
	color: #323232;
}

h1 {
    color: #2E0927; /* Define chapter looks (color) GVD */
}

h3 {
    color: #D90000;
}
    </style>
  </head>
  <body>

  <H1>SELECT i database fra PHP, del 1 (S175-187)</H1>
  
<?php
echo "<H3>Start opp MAMP og sjekk tilkoblingen!</H3>";

// Tilkoblingsinformasjon
$tjener = "localhost";
$brukernavn = "root";
$passord = "root";
$database = "tegneseriefigurer_mb";

// Opprette en kobling
$kobling = new mysqli($tjener, $brukernavn, $passord, $database);

// Sjekk om koblingen virker
if ($kobling->connect_error) {
    die("Noe gikk galt: " . $kobling->connect_error);
} else {
    echo "Koblingen virker.";
}
// Sjekk UTF-8 som tegnsett?
echo "<p>";
echo $kobling->character_set_name();
// Angi UTF-8 som tegnsett
$kobling->set_charset("utf8");
echo "<p>";
echo $kobling->character_set_name();

// Definer utspørring og spør ut
$sql = "SELECT * FROM blad";
$resultat = $kobling->query($sql);

// Presenter resultat # råd 
echo "<H3>resultat # råd</H3>";    
echo "<p>";
echo "Spørringen <i>$sql</i> ga $resultat->num_rows rader. <p>";

// presenter resultat blad_id og bladnavn
echo "<H3>resultat blad_id og bladnavn (enkel)</H3>";
while($rad = $resultat->fetch_assoc()) {
	$blad_id = $rad["blad_id"];
	$bladnavn = $rad["bladnavn"];
	
	echo "$blad_id $bladnavn <br>";
}
	
// presenter resultat blad_id og bladnavn i ett tabell
echo "<H3>resultat blad_id og bladnavn (tabell: igjen utspørring!)</H3>";
echo "<table>";
echo "<tr>";
	echo "<th>blad_id</th>";
	echo "<th>bladnavn</th>";
echo "</tr>";

// Definer utspørring og spør ut
$sql = "SELECT * FROM blad";
$resultat = $kobling->query($sql);

while($rad = $resultat->fetch_assoc()) {
	$blad_id = $rad["blad_id"];
	$bladnavn = $rad["bladnavn"];
	
echo "<tr>";
	echo "<td>$blad_id</td>";
	echo "<td>$bladnavn</td>";
echo "</tr>";
}

echo "</table>";

// enkelt utspørring figur (S184)
echo "<H3>resultat figur (enkel, ny utspørring)</H3>";
// Definer utspørring og spør ut
$sql = "SELECT * FROM figur";
$resultat = $kobling->query($sql);

// Presenter resultat # råd     
echo "<p>";
echo "Spørringen <i>$sql</i> ga $resultat->num_rows rader. <p>";

// presenter resultat figur_id, figurnavn, aarstall og blad_id
while($rad = $resultat->fetch_assoc()) {
	$figur_id = $rad["figur_id"];
	$figurnavn = $rad["figurnavn"];
	$aarstall = $rad["aarstall"];
	$blad_id = $rad["blad_id"];	
	
	echo "$figur_id $figurnavn $aarstall $blad_id<br>";
}

// Hente ut fra flere tabeller i tabell
echo "<H3>Hente ut fra flere tabeller (ny utspørring)</H3>";
// Definer utspørring og spør ut
$sql = "SELECT figurnavn, bladnavn FROM figur JOIN blad ON figur.blad_id=blad.blad_id";
$resultat = $kobling->query($sql);

echo "<table>";
echo "<tr>";
	echo "<th>figurnavn</th>";
	echo "<th>bladnavn</th>";
echo "</tr>";

while($rad = $resultat->fetch_assoc()) {
	$figurnavn = $rad["figurnavn"];
	$bladnavn = $rad["bladnavn"];
	
echo "<tr>";
	echo "<td>$figurnavn</td>";
	echo "<td>$bladnavn</td>";
echo "</tr>";
}

echo "</table>";	

?>

 </body>
</html>